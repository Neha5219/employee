from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from models import User
from database import get_db
from routers.auth import get_current_user
from utils.email_utils import send_email
from schemas import EmailRequest  # 👈 Make sure this is imported

router = APIRouter(prefix="/email", tags=["Email"])

@router.post("/send/")
def send_mail_to_admin_or_user(
    email_data: EmailRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    try:
        send_email(
            to_email=email_data.to_email,
            subject=email_data.subject,
            body=email_data.body
        )
        return {"message": f"Email sent to {email_data.to_email} successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to send email: {str(e)}")
