from fastapi import APIRouter, Depends, HTTPException, Body, Path
from sqlalchemy.orm import Session
from schemas import LeaveRequestCreate, LeaveRequestOut
from database import get_db
import crud
from dependencies import is_admin

from utils.email_utils import send_email
from routers.auth import get_current_user
from models import User
from typing import List  # ✅ required for List[]

router = APIRouter(prefix="/leave", tags=["Leave"])

# apply for leave
@router.post("/")
def apply_leave(
    leave: LeaveRequestCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    return crud.apply_leave(db, employee_id=current_user.id, leave_data=leave)


# ✅ 2. Employee - View their own leaves
# ------------------------------------------
@router.get("/", response_model=List[LeaveRequestOut])
def view_my_leaves(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    return crud.get_leave_requests(db, employee_id=current_user.id)

# ✅ 3. Admin - View all leave requests
# ------------------------------------------
@router.get("/all", response_model=List[LeaveRequestOut])
def view_all_leaves(
    db: Session = Depends(get_db),
    current_user: User = Depends(is_admin)  # ⬅ Only Admin
):
    return crud.get_all_leave_requests(db)

@router.post("/")
def request_leave(
    leave: LeaveRequestCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)  # ✅ correct type
):
    return crud.apply_leave(db, employee_id=current_user.id, leave_data=leave)

@router.get("/", response_model=List[LeaveRequestOut])
def view_leaves(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    return crud.get_leave_requests(db, employee_id=current_user.id)

# ✅ New: Approve Leave
@router.put("/approve/{leave_id}")
def approve_leave(
    leave_id: int = Path(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(is_admin)
):
    leave = crud.update_leave_status(db, leave_id=leave_id, status="Approved")
    send_email(
        to_email=leave.employee.email,
        subject="Leave Approved",
        body=f"Hi {leave.employee.name}, your leave from {leave.start_date} to {leave.end_date} has been approved."
    )
    return leave

# ✅ New: Reject Leave
@router.put("/reject/{leave_id}")
def reject_leave(
    leave_id: int = Path(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(is_admin)
):
     
     leave = crud.update_leave_status(db, leave_id=leave_id, status="Rejected")
     send_email(
        to_email=leave.employee.email,
        subject="Leave Rejected",
        body=f"Hi {leave.employee.name}, your leave from {leave.start_date} to {leave.end_date} has been rejected."
    )
     return leave

# ✅ View Own Leaves (Employee)
@router.get("/", response_model=List[LeaveRequestOut])
def get_my_leaves(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    return crud.get_leave_requests(db, employee_id=current_user.id)

# ✅ View All Leaves (Admin)
@router.get("/all", response_model=List[LeaveRequestOut])
def get_all_leaves(
    db: Session = Depends(get_db),
    current_user: User = Depends(is_admin)
):
    return crud.get_leave_requests(db)


    