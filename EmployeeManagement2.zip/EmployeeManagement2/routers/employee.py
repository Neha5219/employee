from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from schemas import EmployeeCreate, EmployeeOut
from database import SessionLocal
import crud
from routers.auth import get_current_user
from typing import List
from dependencies import is_admin
from models import User

router = APIRouter(
    tags=["Employees"]
)

# ✅ Database dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# ✅ Read all employees
@router.get("/", response_model=List[EmployeeOut])
def read_employees(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    return crud.get_employees(db)

# ✅ Create employee (Admin only)
@router.post("/", response_model=EmployeeOut)
def create_employee(
    emp: EmployeeCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(is_admin)
):
    return crud.create_employee(db, emp)

# ✅ Search employees
@router.get("/search", response_model=List[EmployeeOut])
def search_employees(
    name: str = Query("", description="Search by name"),
    email: str = Query("", description="Search by email"),
    dept: str = Query("", description="Search by department"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    return crud.search_employees(db, name=name, email=email, dept=dept)

# ✅ Paginated employee list
@router.get("/paginated", response_model=List[EmployeeOut])
def read_employees_paginated(
    skip: int = Query(0, ge=0, description="Records to skip"),
    limit: int = Query(10, ge=1, le=100, description="Records to return"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    return crud.get_employees_paginated(db, skip=skip, limit=limit)

# ✅ Update employee (Admin only)
@router.put("/{emp_id}", response_model=EmployeeOut)
def edit_employee(
    emp_id: int,
    emp: EmployeeCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(is_admin)
):
    updated = crud.update_employee(db, emp_id, emp)
    if not updated:
        raise HTTPException(status_code=404, detail="Employee not found")
    return updated

# ✅ Delete employee (Admin only)
@router.delete("/{emp_id}")
def remove_employee(
    emp_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(is_admin)
):
    emp = crud.delete_employee(db, emp_id)
    if not emp:
        raise HTTPException(status_code=404, detail="Employee not found")
    return {"message": "Deleted successfully"}

# ✅ Get employee by ID
@router.get("/{emp_id}", response_model=EmployeeOut)
def read_employee(
    emp_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    emp = crud.get_employee_by_id(db, emp_id)
    if not emp:
        raise HTTPException(status_code=404, detail="Employee not found")
    return emp