const API_BASE = "http://127.0.0.1:8000/api/v1/auth";

// ======================
// LOGIN
// ======================

const loginForm = document.getElementById("loginForm");

if (loginForm) {
    loginForm.addEventListener("submit", async function (e) {
        e.preventDefault();

        console.log("Login button clicked");

        try {
            const username = document.getElementById("username").value;
            const password = document.getElementById("password").value;

            const formData = new URLSearchParams();
            formData.append("username", username);
            formData.append("password", password);

            const response = await fetch(`${API_BASE}/login`, {
                method: "POST",
                body: formData
            });

            const data = await response.json();
            console.log("Login response:", data);

            if (response.ok) {
                localStorage.setItem("token", data.access_token);

                const profileRes = await fetch(`${API_BASE}/me`, {
                    headers: {
                        "Authorization": "Bearer " + data.access_token
                    }
                });

                const profile = await profileRes.json();
                console.log("Profile:", profile);

                if (profile.role === "admin") {
                    window.location.href = "admin.html";
                } else {
                    window.location.href = "employee.html";
                }

            } else {
                alert(data.detail || "Login Failed!");
            }

        } catch (error) {
            console.error("Login error:", error);
            alert("Server error. Check backend or CORS.");
        }
    });
}

// ======================
// SIGNUP
// ======================

const signupForm = document.getElementById("signupForm");

if (signupForm) {
    signupForm.addEventListener("submit", async function (e) {
        e.preventDefault();

        console.log("Signup button clicked");

        try {
            const userData = {
                username: document.getElementById("username").value,
                email: document.getElementById("email").value,
                password: document.getElementById("password").value,
                role: document.getElementById("role").value
            };

            const response = await fetch(`${API_BASE}/signup`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(userData)
            });

            const data = await response.json();
            console.log("Signup response:", data);

            if (response.ok) {
                alert("Signup Successful! Please login.");
                window.location.href = "index.html";
            } else {
                alert(data.detail || "Signup Failed!");
            }

        } catch (error) {
            console.error("Signup error:", error);
            alert("Server error. Check backend or CORS.");
        }
    });
}