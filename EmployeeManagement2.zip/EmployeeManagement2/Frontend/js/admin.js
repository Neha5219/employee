const API_BASE = "http://127.0.0.1:8000/api/v1";

const token = localStorage.getItem("token");

if (!token) {
    window.location.href = "index.html";
}

// Load all leaves
fetch(`${API_BASE}/leave/all`, {
    headers: {
        "Authorization": "Bearer " + token
    }
})
.then(res => res.json())
.then(data => {
    const table = document.getElementById("leaveTable");

    data.forEach(leave => {
        const row = `
            <tr>
                <td>${leave.id}</td>
                <td>${leave.employee_id}</td>
                <td>${leave.start_date}</td>
                <td>${leave.end_date}</td>
                <td>${leave.status}</td>
                <td>
                    <button onclick="approveLeave(${leave.id})">Approve</button>
                    <button onclick="rejectLeave(${leave.id})">Reject</button>
                </td>
            </tr>
        `;
        table.innerHTML += row;
    });
});

// Approve
function approveLeave(id) {
    fetch(`${API_BASE}/leave/approve/${id}`, {
        method: "PUT",
        headers: {
            "Authorization": "Bearer " + token
        }
    })
    .then(() => {
        alert("Leave Approved");
        location.reload();
    });
}

// Reject
function rejectLeave(id) {
    fetch(`${API_BASE}/leave/reject/${id}`, {
        method: "PUT",
        headers: {
            "Authorization": "Bearer " + token
        }
    })
    .then(() => {
        alert("Leave Rejected");
        location.reload();
    });
}

function logout() {
    localStorage.removeItem("token");
    window.location.href = "index.html";
}