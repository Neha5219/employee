from pydantic import BaseModel, EmailStr
from datetime import date


# ---------------- Employee Schemas ----------------
class EmployeeBase(BaseModel):
    dept: str
    name: str
    designation: str
    email: str
    address: str
    married: str
    dob: str
    doj: str
    idproof_type: str
    idproof: str
    gender: str
    phone: str
    country: str
    salary: str

class EmployeeCreate(EmployeeBase):
    pass

class EmployeeOut(EmployeeBase):
    id: int

    class Config:
        from_attributes = True

# ---------------- User/Auth Schemas ----------------
class UserBase(BaseModel):
    username: str
    email: EmailStr
    role: str = "employee"  # 👈 default


class UserCreate(UserBase):
    password: str

class UserOut(UserBase):
    id: int

    class Config:
        from_attributes = True

class UserLogin(BaseModel):
    username: str
    password: str

class Token(BaseModel):
    access_token: str
    token_type: str

# ---------------- Leave Schemas ----------------
from datetime import date
from typing import Optional

class LeaveBase(BaseModel):
    reason: str
    from_date: date
    to_date: date
    status: Optional[str] = "Pending"  # Default

class LeaveCreate(LeaveBase):
    employee_id: int

class LeaveOut(LeaveBase):
    id: int
    employee_id: int

    class Config:
        from_attributes = True
# ---------------- Leave Schemas ----------------
from datetime import date

class LeaveRequestCreate(BaseModel):
    start_date: date
    end_date: date
    reason: str
   

class LeaveRequestOut(BaseModel):
    id: int
    start_date: date
    end_date: date
    reason: str
    status: str           # ✅ Add this
    employee_id: int

    class Config:
        from_attributes = True

# schemas.py
class EmailRequest(BaseModel):
    to_email: EmailStr
    subject: str
    body: str
  

