from sqlalchemy.orm import Session
from models import Employee, LeaveRequest
from schemas import EmployeeCreate, LeaveRequestCreate
from fastapi import HTTPException
from utils.email_utils import send_email


def create_employee(db: Session, emp: EmployeeCreate):
    db_emp = Employee(**emp.dict())
    db.add(db_emp)
    db.commit()
    db.refresh(db_emp)
    return db_emp

def get_employees(db: Session):
    return db.query(Employee).all()

def get_employee_by_id(db: Session, emp_id: int):
    return db.query(Employee).filter(Employee.id == emp_id).first()

def delete_employee(db: Session, emp_id: int):
    emp = db.query(Employee).filter(Employee.id == emp_id).first()
    if emp:
        db.delete(emp)
        db.commit()
    return emp

def update_employee(db: Session, emp_id: int, emp_data: EmployeeCreate):
    emp = db.query(Employee).filter(Employee.id == emp_id).first()
    if emp:
        for key, value in emp_data.dict().items():
            setattr(emp, key, value)
        db.commit()
        db.refresh(emp)
    return emp



def search_employees(db: Session, name: str = "", email: str = "", dept: str = ""):
    query = db.query(Employee)

    if name:
        query = query.filter(Employee.name.ilike(f"%{name}%"))
    if email:
        query = query.filter(Employee.email.ilike(f"%{email}%"))
    if dept:
        query = query.filter(Employee.dept.ilike(f"%{dept}%"))

    return query.all()

def get_employees_paginated(db: Session, skip: int = 0, limit: int = 100):
    return db.query(Employee).offset(skip).limit(limit).all()

def create_leave_request(db: Session, leave: LeaveRequestCreate):
    db_leave = LeaveRequest(**leave.dict())
    db.add(db_leave)
    db.commit()
    db.refresh(db_leave)
    return db_leave

def get_leave_requests(db: Session, employee_id: int = None):
    if employee_id:
        return db.query(LeaveRequest).filter(LeaveRequest.employee_id == employee_id).all()
    return db.query(LeaveRequest).all()

def update_leave_status(db: Session, leave_id: int, status: str):
    leave = db.query(LeaveRequest).filter(LeaveRequest.id == leave_id).first()
    if leave:
        leave.status = status
        db.commit()
        db.refresh(leave)
    return leave

def delete_leave_request(db: Session, leave_id: int):
    leave = db.query(LeaveRequest).filter(LeaveRequest.id == leave_id).first()
    if leave:
        db.delete(leave)
        db.commit()
    return leave
def apply_leave(db: Session, employee_id: int, leave_data: LeaveRequestCreate):
    try:
        leave = LeaveRequest(
            employee_id=employee_id,
            start_date=leave_data.start_date,
            end_date=leave_data.end_date,
            reason=leave_data.reason,
            status="Pending"
        )
        db.add(leave)
        db.commit()
        db.refresh(leave)
        return leave

    except Exception as e:
        print(f"🔥 Error in apply_leave(): {e}")
        raise HTTPException(status_code=500, detail=f"Internal Error: {str(e)}")
    
    # ✅ Add this at the end of crud.py
def update_leave_status(db: Session, leave_id: int, status: str):
    leave = db.query(LeaveRequest).filter(LeaveRequest.id == leave_id).first()
    if not leave:
        raise HTTPException(status_code=404, detail="Leave not found")
    
    leave.status = status
    db.commit()
    db.refresh(leave)

# ✅ Email to employee
    employee = db.query(User).filter(User.id == leave.employee_id).first()
    if employee:
        subject = f"Leave {status}"
        body = f"Hello {employee.username},\n\nYour leave from {leave.start_date} to {leave.end_date} has been {status.lower()}."
        send_email(to_email=employee.email, subject=subject, body=body)

    return leave
   

