from sqlalchemy import Column, String, Integer, ForeignKey, Date
from database import Base
from sqlalchemy.orm import relationship

class Employee(Base):
    __tablename__ = "employees"

    id = Column(Integer, primary_key=True, index=True)
    dept = Column(String)
    name = Column(String)
    designation = Column(String)
    email = Column(String)
    address = Column(String)
    married = Column(String)
    dob = Column(String)
    doj = Column(String)
    idproof_type = Column(String)
    idproof = Column(String)
    gender = Column(String)
    phone = Column(String)
    country = Column(String)
    salary = Column(String)

# ✅ Relationship to LeaveRequest
    leaves = relationship("LeaveRequest", back_populates="employee")


# ✅ User Table (for Authentication)
class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True)
    email = Column(String, unique=True, index=True)
    hashed_password = Column(String)
    role = Column(String, default="employee")

# ✅ New LeaveRequest model for Leave Management
class LeaveRequest(Base):
    __tablename__ = "leave_requests"

    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, ForeignKey("employees.id"))
    start_date = Column(String)
    end_date = Column(String)
    reason = Column(String)
    status = Column(String, default="Pending")

    employee = relationship("Employee", back_populates="leaves")

