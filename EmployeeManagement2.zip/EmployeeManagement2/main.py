from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer
from fastapi.openapi.utils import get_openapi

from database import Base, engine
from routers import auth, employee, leave, email


oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login")

app = FastAPI(
    title="Employee Management API",
    description="A FastAPI backend with JWT auth",
    version="1.0.0",
    openapi_tags=[
        {"name": "Authentication", "description": "Login and Signup"},
        {"name": "Employees", "description": "Employee CRUD operations"},
        {"name": "Leave", "description": "Apply/Approve/Reject Leave"},
        {"name": "Email", "description": "Send emails"},
    ]
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://127.0.0.1:5500",
        "http://localhost:5500"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ✅ Auto-generate database tables
Base.metadata.create_all(bind=engine)

# ✅ Routers
app.include_router(auth.router, prefix="/api/v1/auth")
app.include_router(employee.router, prefix="/api/v1/employees")
app.include_router(leave.router, prefix="/api/v1/leave")
app.include_router(email.router, prefix="/api/v1/email")


# ✅ Root endpoint
@app.get("/")
def read_root():
    return {"message": "Welcome to Employee Management!"}


# ✅ Custom OpenAPI Schema for Swagger to show Authorize button
def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema

    openapi_schema = get_openapi(
        title=app.title,
        version=app.version,
        description=app.description,
        routes=app.routes,
    )

    openapi_schema["components"]["securitySchemes"] = {
        "BearerAuth": {
            "type": "http",
            "scheme": "bearer",
            "bearerFormat": "JWT"
        }
    }

    for path in openapi_schema["paths"]:
        for method in openapi_schema["paths"][path]:
            if method in ["get", "post", "put", "delete", "patch"]:
                openapi_schema["paths"][path][method]["security"] = [{"BearerAuth": []}]

    app.openapi_schema = openapi_schema
    return app.openapi_schema


app.openapi = custom_openapi
